#ifndef __PID_H
#define __PID_H

#include "stm32f4xx.h"

typedef struct
{
	float desired;			//< set point
	float input;				//< input
	float error;        //< error
	float preError;    //< previous error
	float integ;        //< integral
	float integ_sep;		//< integral separation
	float deriv;        //< derivative
	float kp;           //< proportional gain
	float ki;           //< integral gain
	float kd;           //< derivative gain
	float outP;         //< proportional output (debugging)
	float outI;         //< integral output (debugging)
	float outD;         //< derivative output (debugging)
	float iLimit;       //< integral limit
	float outputLimit;  //< total PID output limit, absolute value. '0' means no limit.
	float dt;           //< delta-time dt
	float out;					//< out
} PidObject;

void PID_Init(void);
void Pid_Update(PidObject* pid, const float error);
//���A�͵��B��ת�ٱջ�PID
extern PidObject PID_PWMA;				//���Aת�ٱջ�
extern PidObject PID_PWMB;				//���Bת�ٱջ�
//���������ת�ٱջ�����������ת��
float Control_PWMA(float cnt_A);
float Control_PWMB(float cnt_B);
#endif

