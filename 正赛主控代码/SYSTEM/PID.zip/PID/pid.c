#include "pid.h"
#include "math.h"
#include "motor.h"

//���A�͵��B��ת�ٱջ�PID
PidObject PID_PWMA;
PidObject PID_PWMB;

void PID_Init(void)
{
/*
*************************************
* 		���Aת�ٱջ�PID������ʼ��			
*************************************
*/	
	PID_PWMA.desired = 50;				//���A��ת������
	PID_PWMA.kp = 10;						//���Aת�ٱջ�P
	PID_PWMA.ki = 0;
	PID_PWMA.integ_sep = 0;
	PID_PWMA.dt = 0;
	PID_PWMA.iLimit = 0;
	
	
}

void Pid_Update(PidObject* pid, const float error)
{
	float output;
	pid->error = error;
	
	if((pid->error < pid->integ_sep) && (pid->error > -pid->integ_sep))
		pid->integ += pid->error * pid->dt;
	else pid->integ = 0;
	
	if(pid->integ > pid->iLimit )
		pid->integ = pid->iLimit;
	else if(pid->integ < -pid->iLimit)
		pid->integ = -pid->iLimit;
	
	pid->deriv = pid->error - pid->preError;
	
	pid->outP = pid->kp * pid->error;
	pid->outI = pid->ki * pid->integ;
	pid->outD = pid->kd * pid->deriv;
	
	output = pid->outP + pid->outI + pid->outD;
	
	if(pid->outputLimit!=0)
	{
		if(output > pid->outputLimit)
			output = pid->outputLimit;
		else if(output < -pid->outputLimit)
			output = -pid->outputLimit;
	}
	
	pid->preError = pid->error;
	pid->out = output;
}

float Control_PWMA(float cnt_A)
{
	PID_PWMA.error = PID_PWMA.desired - cnt_A;
	Pid_Update(&PID_PWMA, PID_PWMA.error);
	AIN1 += PID_PWMA.out;
}


