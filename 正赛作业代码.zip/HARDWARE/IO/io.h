#ifndef __IO_H
#define __IO_H	 
#include "sys.h"

void IO_Init(void);
		 				    
#endif
