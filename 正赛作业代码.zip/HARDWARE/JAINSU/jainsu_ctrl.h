#ifndef __JAINSU_CTRL_H
#define __JAINSU_CTRL_H
#include "stdio.h"	
#include "sys.h" 