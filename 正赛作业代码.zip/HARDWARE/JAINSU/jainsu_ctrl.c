#include "stdio.h"
#include "jainsu_ctrl.h"


void jiansu_