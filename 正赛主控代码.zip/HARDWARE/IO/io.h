#ifndef __IO_H
#define __IO_H

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"

//#define Mv1_1  		PEout(7)
//#define Mv1_2     PEout(8)

void IO_init();

#endif