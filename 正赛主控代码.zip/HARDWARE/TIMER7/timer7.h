#ifndef __TIMER7_H
#define __TIMER7_H
#include "sys.h"

void TIM7_Init(u16 arr, u16 psc);

#endif

